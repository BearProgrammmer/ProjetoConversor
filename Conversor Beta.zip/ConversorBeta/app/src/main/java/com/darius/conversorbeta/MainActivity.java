package com.darius.conversorbeta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    EditText receber;
    TextView resultado;
    Button resultar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        receber = findViewById(R.id.input);
        resultado = findViewById(R.id.output);
        resultar = findViewById(R.id.botao);

        resultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double valor = Double.parseDouble(receber.getText().toString());

                DecimalFormat arredondar = new DecimalFormat("#.##");
                double convertido = Double.parseDouble(arredondar.format(valor * 0.80));

                resultado.setText(String.valueOf(convertido)+"$"); //+"$" inclui no texto
            }
        });
    }
}